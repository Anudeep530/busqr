package com.example.loginpage;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CapturAct extends CaptureActivity {
}
