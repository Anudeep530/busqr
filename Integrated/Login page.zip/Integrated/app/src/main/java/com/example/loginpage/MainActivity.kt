package com.example.loginpage

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.loginpage.databinding.ActivityMainBinding
import okhttp3.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import retrofit2.http.Headers

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.loginButton.setOnClickListener {

            val username = binding.username.text.toString()
            val password = binding.password.text.toString()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(
                    this,
                    "Username and password fields cannot be empty",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            // Make API call to authenticate the user with the entered credentials
            authenticateUser(username, password)
        }

    }

    private fun authenticateUser(username: String, password: String) {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://webprosindia.com/bvritnt/")
            .addConverterFactory(GsonConverterFactory.create())
            .build();

        val api = retrofit.create(AuthAPI::class.java)
        val call = api.authenticate(username, password)




        call.enqueue(object : Callback<AuthResponse> {
            override fun onResponse(
                call: Call<AuthResponse>,
                response: Response<AuthResponse>
            ) {
                if (response.isSuccessful && response.body()!!.success) {
                    binding.username.text.clear()
                    binding.password.text.clear()
                    val intent = Intent(this@MainActivity, act::class.java)
                    startActivity(intent)
                    Toast.makeText(
                        this@MainActivity,
                        "Authentication Successful",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    val builder = AlertDialog.Builder(this@MainActivity)
                    val message = ""+response
                    val textView = TextView(this@MainActivity)
                    textView.text = message
                    textView.setPadding(20, 20, 20, 20)
                    textView.textSize = 18f
                    builder.setView(textView)
                    builder.setPositiveButton("OK") { _, _ -> }
                    builder.create().show()

                }
            }

            override fun onFailure(call: Call<AuthResponse>, t: Throwable) {
                Toast.makeText(this@MainActivity, "API Call Failed", Toast.LENGTH_SHORT).show()
            }
        })
    }
}

interface AuthAPI {

    @GET("api/checkstudent/rollno/password")
    @Headers("Authorization: Bearer cQM89mnmdFyD5jHls6HLXBAjOsjnMqSacQgJvi8S9DntdGQT7zEDT6XEx8zH+ImxseNazWUdxKzMKQz5FEVuyIkyQ2+dgeqGoD6GdagoLp3oyjeJ0qbC8B6RThYFNtRAFqO55YohjweO0B+Ng5tsGPJsQwlhOvE8")
    fun authenticate(@Query("rollno") username: String, @Query("password") password: String): Call<AuthResponse>
}



data class AuthResponse(val success: Boolean)
