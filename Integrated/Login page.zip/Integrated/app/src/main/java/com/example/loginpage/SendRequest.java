package com.example.loginpage;

public class SendRequest {
}
