package com.example.loginpage;

public class User {
    public  String username;
    public String password;
    public String getUsername() {
        return username;
    }
}
