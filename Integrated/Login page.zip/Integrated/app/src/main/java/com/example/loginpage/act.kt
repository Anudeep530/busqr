package com.example.loginpage

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.ImageButton
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.example.loginpage.R.id.drawerLayout
import com.example.loginpage.R.id.imageButton
import com.example.loginpage.databinding.ActivityMainBinding


class act : AppCompatActivity() {

    lateinit var toggle: ActionBarDrawerToggle
    lateinit var drawerLayout: DrawerLayout


    @SuppressLint("RestrictedApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)



        setContentView(R.layout.act)
        val callback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Handle back button press here
            }
        }
        onBackPressedDispatcher.addCallback(this, callback)


        drawerLayout = findViewById(R.id.drawerLayout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigationView)

        toggle = ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close)
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        val b1 = findViewById<ImageButton>(imageButton)
        b1.setOnClickListener {
            val intent = Intent(this, busQR::class.java)
            startActivity(intent)
        }

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        navView.setNavigationItemSelectedListener {

            it.isChecked = true

            when (it.itemId) {

                R.id.nav_hallticket -> replaceFragement(HallTicket(), it.title.toString())
                R.id.nav_results -> replaceFragement(Results(), it.title.toString())
                R.id.nav_backlogs -> replaceFragement(backlogs(), it.title.toString())
                R.id.nav_requests -> replaceFragement(Requests(), it.title.toString())
                R.id.nav_openelectives -> replaceFragement(OpenElectives(), it.title.toString())
                R.id.nav_coursereg -> replaceFragement(CourseReg(), it.title.toString())
                R.id.nav_settings -> replaceFragement(Settings(), it.title.toString())
                R.id.nav_Help -> replaceFragement(Settings(), it.title.toString())
                R.id.nav_logout -> replaceFragement(Logout(), it.title.toString())

            }
            true
        }

        bottomNavigationView.setOnItemSelectedListener {

            when (it.itemId) {

                R.id.Home -> {
                    val intent = Intent(baseContext, act::class.java)
                    if (baseContext != null) {
                        startActivity(intent)
                    }


                }
                R.id.attendance -> replaceFragement(attendance(), it.title.toString())
                R.id.notifications -> replaceFragement(Bnotifiactions(), it.title.toString())
                R.id.receipts -> replaceFragement(Breceipts(), it.title.toString())
                else -> {

                }
            }
            true
        }
    }




    private fun replaceFragement(fragment: Fragment, title: String){

        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.frame_layout,fragment)
        fragmentTransaction.commit()
        drawerLayout.closeDrawers()
        setTitle(title)

    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if (toggle.onOptionsItemSelected(item)){

            return true
        }
        return super.onOptionsItemSelected(item)
    }




    }
