package com.example.loginpage;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class busQR extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_qr);



            scanCode();
    }

    private void scanCode() {
        ScanOptions options = new ScanOptions();
        options.setPrompt("volume up to flash on");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        options.setCaptureActivity(CapturAct.class);
        barLauncher.launch(options);

    }


    ActivityResultLauncher<ScanOptions> barLauncher = registerForActivityResult(new ScanContract(),result ->
    {
        //To on successful scan satisfy condition
        if(result.equals("hi"))
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(busQR.this);



            builder.setTitle("Result").show();
            //displays msg after successful scan
            builder.setMessage("Authentication Successful").show();
            //To display ok button to dismiss msg
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    Intent intent = new Intent(getApplicationContext(), MedianQR.class);
                    startActivity(intent);
                }

            }).show();



        }
        else{
            Intent intent = new Intent(getApplicationContext(), act.class);
            startActivity(intent);
            Toast.makeText(getApplicationContext(), "Try Again",Toast.LENGTH_SHORT).show();
        }
    });
}